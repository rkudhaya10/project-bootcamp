import React from "react";

function Info() {
  return (
    <div className="note">
      <h1>Java script and React.Js</h1>
      <p>ShapeAI Bootcamp</p>
      <h1>ShapeAI Bootcamp 2021</h1>
      <p>Shaurya sinha</p>
    </div>
  );
}

export default Info;
